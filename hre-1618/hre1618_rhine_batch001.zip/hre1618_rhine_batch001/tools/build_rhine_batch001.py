#!/usr/bin/env python3
"""Build Rhine city/connector sprites on the repository's *existing* AD 1618 base.

Run from hre-1618/: python tools/build_rhine_batch001.py
Requires pillow. Downloads the same Natural Earth 10m river data as build_base.py
(unless --rivers-zip supplies the existing rivers.zip). All coordinates match
base_3600.jpg's Lambert Conformal Conic projection. This makes no new base map.

NOTE: Natural Earth is a generalized modern geographic reference. It is NOT
an exact reconstruction of river channels in AD 1618. Review bridges, banks,
city scale and water course before accepting/merging map placement.
"""
import argparse, io, json, math, struct, urllib.request, zipfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CFG=ROOT / 'placements/batch-001.json'
RIVER_URL='https://naturalearth.s3.amazonaws.com/10m_physical/ne_10m_rivers_lake_centerlines.zip'
W,H=3600,4800
R=math.radians
a=6378137.0; f=1/298.257223563; e2=2*f-f*f; e=math.sqrt(e2)
lat1,lat2,lat0,lon0=44.84,53.02,48.93,10.67
XMIN,XMAX,YMIN,YMAX=-503671,504058,-661508,682131

def m(p): return math.cos(p)/math.sqrt(1-e2*math.sin(p)**2)
def t(p): return math.tan(math.pi/4-p/2)/((1-e*math.sin(p))/(1+e*math.sin(p)))**(e/2)
n=(math.log(m(R(lat1)))-math.log(m(R(lat2))))/(math.log(t(R(lat1)))-math.log(t(R(lat2))))
F=m(R(lat1))/(n*t(R(lat1))**n); rho0=a*F*t(R(lat0))**n

def px(la,lo):
    rho=a*F*t(R(la))**n; th=n*(R(lo)-R(lon0))
    x=rho*math.sin(th); y=rho0-rho*math.cos(th)
    return ((x-XMIN)/(XMAX-XMIN)*W,(YMAX-y)/(YMAX-YMIN)*H)


def dbf_names(data):
    count=struct.unpack('<I',data[4:8])[0]
    header,record=struct.unpack('<HH',data[8:12]); cols=[]; p=32
    while data[p]!=13:
        cols.append((data[p:p+11].split(b'\0')[0].decode(),data[p+16]));p+=32
    values=[]
    for i in range(count):
        row=data[header+i*record:header+(i+1)*record]; off=1; name=''
        for key,size in cols:
            if key=='name':name=row[off:off+size].decode('latin-1').strip(' \0')
            off+=size
        values.append(name)
    return values


def rhine_lines(zdata):
    with zipfile.ZipFile(io.BytesIO(zdata)) as z:
        shp=z.read(next(x for x in z.namelist() if x.endswith('.shp')))
        dbf=z.read(next(x for x in z.namelist() if x.endswith('.dbf')))
    names=dbf_names(dbf); output=[]; pos=100; idx=0
    while pos+8<=len(shp):
        size=struct.unpack('>i',shp[pos+4:pos+8])[0]*2
        rec=shp[pos+8:pos+8+size];pos+=8+size
        if idx<len(names) and names[idx].lower() in ('rhine','rhein','rhin') and struct.unpack('<i',rec[:4])[0]==3:
            parts,npts=struct.unpack('<ii',rec[36:44]); offsets=list(struct.unpack('<%di'%parts,rec[44:44+4*parts]))+[npts]
            pairs=struct.unpack('<%dd'%(2*npts),rec[44+4*parts:44+4*parts+16*npts])
            vertices=[(pairs[2*i+1],pairs[2*i]) for i in range(npts)]
            for j in range(parts):
                p=vertices[offsets[j]:offsets[j+1]]
                # Upper Rhine and Mainz region only. Segments of the actual
                # polyline are drawn; never draw straight between cities.
                if len(p)>1 and any(47.4<lat<50.15 and 7.25<lon<8.85 for lat,lon in p):
                    output.append(p)
        idx+=1
    if not output: raise RuntimeError('No Rhine segments found in Natural Earth river data')
    return output


def paint_river(lines):
    overlay=Image.new('RGBA',(W,H),(0,0,0,0))
    d=ImageDraw.Draw(overlay)
    count=0
    for line in lines:
        # Clip per segment to the batch corridor, preserving true source geometry.
        for (lat0,lon0),(lat1,lon1) in zip(line,line[1:]):
            if not (47.45<max(lat0,lat1) and min(lat0,lat1)<50.12): continue
            if not (7.15<max(lon0,lon1) and min(lon0,lon1)<8.95): continue
            a0,a1=px(lat0,lon0),px(lat1,lon1)
            d.line((a0,a1),fill=(78,119,126,220),width=15)
            d.line((a0,a1),fill=(53,111,140,244),width=11)
            d.line((a0,a1),fill=(120,165,177,120),width=3)
            count+=1
    if count<10: raise RuntimeError(f'Insufficient source line segments: {count}')
    return overlay


def water_mask_from_base(river):
    """Keep the river from being overwritten by city artwork.

    The mask is thickened slightly around the mapped river centerline.
    Bridges will need separate historic placement after QA.
    """
    alpha=river.getchannel('A').point(lambda v:255 if v>15 else 0)
    return alpha.filter(ImageFilter.MaxFilter(9))


def place_city(composite,river_mask,city,working_size):
    src=ROOT / city['source']
    if not src.is_file():
        print('Missing city sprite:',src.name);return None
    spr=Image.open(src).convert('RGBA')
    spr.thumbnail((working_size,working_size),Image.Resampling.LANCZOS)
    x,y=map(lambda v:round(v),city['pixel_3600'])
    left,top=x-spr.width//2,y-spr.height//2
    # Cut out the existing river course regardless of water painted in sprite.
    # This protects the continuous river but temporarily omits bridges wherever
    # a painting would otherwise cross it. A separately aligned bridge can follow.
    protection=river_mask.crop((left,top,left+spr.width,top+spr.height))
    alph=spr.getchannel('A')
    from PIL import ImageChops
    spr.putalpha(ImageChops.subtract(alph,protection))
    composite.alpha_composite(spr,(left,top))
    return {'site':city['site'],'x':left,'y':top,'w':spr.width,'h':spr.height,'source':city['source']}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--rivers-zip',type=Path,default=None)
    p.add_argument('--size',type=int,default=None,help='sprite width at 3600px working canvas')
    args=p.parse_args()
    cfg=json.loads(CFG.read_text())
    base_path=ROOT/'base/base_3600.jpg'
    if not base_path.is_file():raise FileNotFoundError('The existing base/base_3600.jpg must be present')
    base=Image.open(base_path).convert('RGBA')
    if base.size!=(W,H):raise ValueError('Unexpected base size; do not scale the geographic reference')
    data=args.rivers_zip.read_bytes() if args.rivers_zip else urllib.request.urlopen(RIVER_URL,timeout=60).read()
    river=paint_river(rhine_lines(data))
    out=ROOT/'reports/rhine-batch-001';out.mkdir(parents=True,exist_ok=True)
    river.save(out/'rhine-connected-overlay-3600.png')
    # Crop one full-raster connector overlay into nonoverlapping geographic
    # y-bands. Reassembly at their stored x,y reproduces a continuous course.
    yy=[0]+sorted(round((cfg['cities'][j]['pixel_3600'][1]+cfg['cities'][j+1]['pixel_3600'][1])/2) for j in range(len(cfg['cities'])-1))+[H]
    connectors=[]
    for i,(y0,y1) in enumerate(zip(yy,yy[1:])):
        band=river.crop((0,y0,W,y1)); bbox=band.getbbox()
        if not bbox:continue
        tile=band.crop(bbox)
        fn=f'connector-{i+1:02d}.png';tile.save(out/fn)
        connectors.append({'file':fn,'x':bbox[0],'y':y0+bbox[1],'w':tile.width,'h':tile.height})
    # The existing underlay stays authoritative; first paint the exact-centerline
    # connector overlay, then keep its water unobstructed by city PNGs.
    composite=Image.alpha_composite(base,river)
    protect=water_mask_from_base(river)
    placements=[]
    for c in cfg['cities']:
        placed=place_city(composite,protect,c,args.size or cfg['sprite_size_px_working'])
        if placed:placements.append(placed)
    composite.convert('RGB').save(out/'rhine-batch-001-on-existing-base.jpg',quality=92)
    crop=(850,1900,1450,3140)
    composite.crop(crop).convert('RGB').save(out/'rhine-batch-001-detail.jpg',quality=93)
    (out/'placement-manifest.json').write_text(json.dumps({'base':str(base_path.relative_to(ROOT)),'projection':'same as build_base.py','cities':placements,'connectors':connectors,'status':'PROVISIONAL; source waterway is modern Natural Earth 10m, historical QA needed'},indent=2)+'\n')
    print('Rendered into',out)

if __name__=='__main__':main()
